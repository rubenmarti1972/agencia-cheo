export const ANIMALITOS_BET_UID = 'api::animalitos-bet.animalitos-bet';
