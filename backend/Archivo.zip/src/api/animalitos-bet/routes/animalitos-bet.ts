import { factories } from '@strapi/strapi';
import { ANIMALITOS_BET_UID } from '../constants';

export default factories.createCoreRouter(ANIMALITOS_BET_UID);
