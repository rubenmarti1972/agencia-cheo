/**
 * Exportaciones centralizadas de servicios
 */

export {
  TicketsUpdaterService,
  getTicketsUpdater
} from './tickets-updater.service';

export {
  ResultsService,
  getResultsService
} from './results.service';
